﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> family;

        public Family()
        {
            this.family = new List<Person>();
        }
        public List<Person> FamilyPerson
        {
            get
            {
                return this.family;
            }

            set
            {
                this.family = value;
            }
        }

        public void AddMember(Person family)
        {
            FamilyPerson.Add(family);
        }

        public Person GetOldestMember(Family familyMembers)
        {
            int oldestAge = int.MinValue;
            Person oldest = null;
            foreach (Person person in family)
            {
                if (person.Age > oldestAge) 
                {
                    oldestAge = person.Age;
                    oldest = person;
                }
            }

            return oldest;
        }
    }
}
