﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WildFarm.Models
{
    public class Vegetable 
        : Food
    {
        public Vegetable(int quantity) : base(quantity)
        {
        }
    }
}
